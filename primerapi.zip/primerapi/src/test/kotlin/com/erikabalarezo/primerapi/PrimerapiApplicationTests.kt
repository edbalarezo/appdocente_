package com.erikabalarezo.primerapi

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PrimerapiApplicationTests {

	@Test
	fun contextLoads() {
	}

}
