CREATE TABLE IF NOT EXISTS gerente (
  id SERIAL,
  nombre VARCHAR (100) NOT NULL,
  cedula INT,
  PRIMARY KEY (id)
  );