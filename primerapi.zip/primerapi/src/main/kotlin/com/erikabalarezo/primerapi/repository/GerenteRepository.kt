package com.erikabalarezo.primerapi.repository

import com.erikabalarezo.primerapi.model.Gerente
import org.springframework.data.jpa.repository.JpaRepository

interface GerenteRepository: JpaRepository <Gerente, Long>{

}