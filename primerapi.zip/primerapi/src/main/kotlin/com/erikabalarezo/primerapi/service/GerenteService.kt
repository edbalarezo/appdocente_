package com.erikabalarezo.primerapi.service

import com.erikabalarezo.primerapi.model.Gerente
import com.erikabalarezo.primerapi.repository.GerenteRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service


@Service
class GerenteService {

    @Autowired
    lateinit var gerenteRepository: GerenteRepository

    fun list ():List<Gerente>{
        return gerenteRepository.findAll()
    }
}