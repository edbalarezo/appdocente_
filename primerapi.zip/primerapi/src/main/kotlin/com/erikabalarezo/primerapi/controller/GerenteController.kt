package com.erikabalarezo.primerapi.controller

import com.erikabalarezo.primerapi.model.Gerente
import com.erikabalarezo.primerapi.service.GerenteService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController


@RestController
@RequestMapping ("/gerente")

class GerenteController {

    @Autowired
    lateinit var gerenteService: GerenteService

    @GetMapping
    fun list(): List<Gerente>{
        return gerenteService.list()
    }
}